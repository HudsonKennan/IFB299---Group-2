IFB299 Final Release

For dynamic testing of the final release, please head to www.redhouserealestate.phyllisyaw.com to test search, search results, individual property pages, registration and login/logout.
To test the entirety of the site, please set up a local MySQL database with the following user access settings and import the SQL dump found in the Database folder.

Hostname: localhost;
Database Name: phyllisy_rhre;
User: phyllisy_ifb299;
Password: Miggles_3;

Then copy the entire release to C:\inetpub\wwwroot and access index.php through localhost/IFB299_Team2_Final_Release/index.php in your preferred web browser. Assuming there are no issues, property management and account management should now also be functional