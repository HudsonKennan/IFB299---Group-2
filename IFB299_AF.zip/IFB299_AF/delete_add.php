<!Doctype html>
<html>
<head>
    <title>Connecting to a Data Base Code</title>
</head>
    <link rel="stylesheet" href="css/mystyle.css">
    <body>
        <!-- This section is used to connect and verify if the connect and the database can be 
            found
        -->
        
        <?php
            $con = mysql_connect('localhost' ,'root' ,'');
            $db = mysql_select_db('redhouse');
        
        if(isset($_POST['update'])){
        $Updatequery = "UPDATE users SET fname='$_POST[namef]', lname='$_POST[namel]', email='$_POST[email]', dob='$_POST[dob]', gender='$_POST[gender]', renting='$_POST[renting]', address='$_POST[address]', phno='$_POST[phno]'  WHERE userID='$_POST[hidden]'";
        mysql_query($Updatequery, $con);
        };
        
        
        
        if(isset($_POST['delete'])){
        $Deletequery = "DELETE FROM users WHERE userID='$_POST[hidden]'";
        mysql_query($Deletequery, $con);
        };
        
        
        
        if(isset($_POST['add'])){
        $Addquery = "INSERT INTO users (fname, lname, email, DOB, Gender, Renting, Address, PHNO, Permissions) VALUES ('$_POST[ufname]','$_POST[ulname]','$_POST[uemail]','$_POST[udob]', '$_POST[ugender]','$_POST[urenting]','$_POST[uaddress]','$_POST[uphno]','$_POST[upermissions]')";
        mysql_query($Addquery, $con);
        };
        
        
        
        ?>
    <br/>
    <br/>
        
        <?php
            $query = mysql_query("SELECT * FROM users");
        
        while($row = mysql_fetch_array($query)){
            $id = $row['userID'];
            $fname = $row['fname'];
            $lname = $row['lname'];
            $email = $row['email'];
            $dob = $row['DOB'];
            $gender = $row['Gender'];
            $renting = $row['Renting'];
            $address = $row['Address'];
            $phno = $row['PHNO'];
            
            echo "<form action=delete_add.php method=post>";
            echo "<tr>";
            echo "<td>" . "<input type=text name=namef value=" . $fname . " </td>";
            echo "<td>" . "<input type=text name=namel value=" . $lname . " </td>";
            echo "<td>" . "<input type=text name=email value=" . $email . " </td>";
            echo "<td>" . "<input type=text name=dob value=" . $dob . " </td>";
            echo "<td>" . "<input type=text name=gender value=" . $gender . " </td>";
            echo "<td>" . "<input type=text name=renting value=" . $renting . " </td>";
            echo "<td>" . "<input type=text name=address value=" . $address . " </td>";
            echo "<td>" . "<input type=text name=phno value=" . $phno . " </td>";
            echo "<td>" . "<input type=hidden name=hidden value=" .  $id . " </td>";
            echo "<td>" . "<input type=submit name=update value=update" . " </td>";
            echo "<td>" . "<input type=submit name=delete value=delete" . " </td>";
            echo "<tr>";
            echo "</form>";
        }
            echo "<form action=delete_add.php method=post>";
            echo "<tr>";
            echo "<td><input type=text placeholder=FirstName name=ufname></td>";
            echo "<td><input type=text placeholder=LastName name=ulname></td>";
            echo "<td><input type=text placeholder=Email name=uemail></td>";
            echo "<td><input type=text placeholder=DateOfBirth name=udob></td>";
            echo "<td><input type=text placeholder=Gender name=ugender></td>";
            echo "<td><input type=text placeholder=Renting(y/n?) name=urenting></td>";
            echo "<td><input type=text placeholder=Address name=uaddress></td>";
            echo "<td><input type=text placeholder=Mobile name=uphno></td>";
            echo "<td><input type=text placeholder=Permission name=upermissions></td>";
            
            echo "<td>" . "<input type=submit name=add value=add" . " </td>";
            echo "</form>";
            echo "</table>";
            mysql_close($con);
        

        ?>
    </body>
</html>