<!Doctype html>
<html>
<head>
    <title>Connecting to a Data Base Code</title>
</head>
    <body>
        <!-- This section is used to connect and verify if the connect and the database can be 
            found
        -->
        
        <?php
            $con = mysql_connect('localhost' ,'root' ,'');
            $db = mysql_select_db('redhouse');
        
            if($con){
                echo 'Succesfully Connected to the database - ';
            }else{
                die('What the fuck you doing damo, you drop kick cunt!');
            }
        
            if($db){
                echo 'Successfully found the database - ';
            } else {
                die('Error: Database not found');
            }
        ?>
    <br/>
    <br/>
        
        <?php
            $query = mysql_query("SELECT * FROM property");
        
        while($row = mysql_fetch_array($query)){
            $id = $row['propertyID'];
            $address = $row['address'];
            
            echo $id . ': ' . 
                 $address . '<br />';     
        }
        ?>
    </body>
</html>