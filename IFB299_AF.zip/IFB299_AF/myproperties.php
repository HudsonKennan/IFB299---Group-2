<!DOCTYPE html>
        
<?php
        $con = mysql_connect('localhost' ,'root' ,'');
        $db = mysql_select_db('redhouse');
        
        if(isset($_POST['update'])){
        $Updatequery = "UPDATE property SET suburb='$_POST[suburb]', pType='$_POST[pType]', furnis='$_POST[furnis]', address='$_POST[address]', bedrooms='$_POST[bedrooms]', garage='$_POST[garage]', rent='$_POST[rent]', descr='$_POST[descr]', available='$_POST[available]'  WHERE propertyID='$_POST[hidden]'";
        mysql_query($Updatequery, $con);
        };
        
        
        
        if(isset($_POST['delete'])){
        $Deletequery = "DELETE FROM property WHERE propertyID='$_POST[hidden]'";
        mysql_query($Deletequery, $con);
        };
        
        
        
        if(isset($_POST['add'])){
        $Addquery = "INSERT INTO property (suburb, pType, furnis, address, bedrooms, garage, rent, descr, available) VALUES ('$_POST[usuburb]','$_POST[upType]','$_POST[ufurnis]','$_POST[uaddress]', '$_POST[ubedrooms]','$_POST[ugarage]','$_POST[urent]','$_POST[udescr]','$_POST[uavailable]')";
        mysql_query($Addquery, $con);
        };
               
?>


<html>
<head>
    <title>Red House Real Estate</title>
    <meta charset="UTF-8"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,700|Squada+One" rel="stylesheet">
</head>

<body>
    <div id="header">
        <img src="img/RHRE%20Logo.svg" alt="Red House Rentals Logo"/>
        <div id="login">
            <a href="login.php">login</a>|<a href="register.php">register</a>|<a href="account_s.php">Settings</a>|<a href="myproperties.php">MyProperties</a>
        </div>
    </div>
    
    <div id="nav_menu">
        <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="search.php">Search</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </div>
    
    <!--create main content area-->
    <div id="content">
        <div id="form">
            <form method="post" name=propertyedit id="registration">
                <fieldset>
                    <legend>Property Listings</legend>
                    <table>
                        <tr>
                                    <?php
            $query = mysql_query("SELECT * FROM property");
        
        while($row = mysql_fetch_array($query)){
            $id = $row['propertyID'];
            $suburb = $row['suburb'];
            $pType = $row['pType'];
            $furnis = $row['furnis'];
            $address = $row['address'];
            $bedrooms = $row['bedrooms'];
            $garage = $row['garage'];
            $rent = $row['rent'];
            $descr = $row['descr'];
            $available = $row['available'];
            
            echo "<form action=myproperties.php method=post>";
            echo "<tr>";
            echo "<td>" . "<input type=text name=suburb value=" . $suburb . " </td>";
            echo "<td>" . "<input type=text name=pType value=" . $pType . " </td>";
            echo "<td>" . "<input type=text name=furnis value=" . $furnis . " </td>";
            echo "<td>" . "<input type=text name=address value=" . $address . " </td>";
            echo "<td>" . "<input type=text name=bedrooms value=" . $bedrooms . " </td>";
            echo "<td>" . "<input type=text name=garage value=" . $garage . " </td>";
            echo "<td>" . "<input type=text name=rent value=" . $rent . " </td>";
            echo "<td>" . "<input type=text name=descr value=" . $descr . " </td>";
            echo "<td>" . "<input type=text name=available value=" . $available . " </td>";
            echo "<td>" . "<input type=hidden name=hidden value=" .  $id . " </td>";
            echo "<td>" . "<input type=submit name=update value=update" . " </td>";
            echo "<td>" . "<input type=submit name=delete value=delete" . " </td>";
            echo "<tr>";
            echo "</form>";
        }
            echo "<form action=myproperties.php method=post>";
            echo "<tr>";
            echo "<td><input type=text placeholder=Suburb name=usuburb></td>";
            echo "<td><input type=text placeholder=Property Type name=upType></td>";
            echo "<td><input type=text placeholder=Furnished name=ufurnis></td>";
            echo "<td><input type=text placeholder=Address name=uaddress></td>";
            echo "<td><input type=text placeholder=Bedrooms name=ubedrooms></td>";
            echo "<td><input type=text placeholder=Garage name=ugarage></td>";
            echo "<td><input type=text placeholder=Rent name=urent></td>";
            echo "<td><input type=text placeholder=Description name=udescr></td>";
            echo "<td><input type=text placeholder=Availbility name=uavailable></td>";
            
            echo "<td>" . "<input type=submit name=add value=add" . " </td>";
            echo "</form>";
            echo "</table>";
            mysql_close($con);
        

        ?>
                        </tr>
                    </table>
                </fieldset>
            </form>
        </div>
<br>
        
                
            </div>
        
        
    
    <div id="footer">
        <p><a href="index.php">Home</a>|<a href="about.php">About</a></p>
        <p>This website was created by Connor Nicholls, Hudson Kennan, Jessica Cockett and Phyllis Yaw for IFB299<br>
        Tutor: Prakash Bhandari, 12-2pm Wednesday</p>
    </div>

</body>
</html>
