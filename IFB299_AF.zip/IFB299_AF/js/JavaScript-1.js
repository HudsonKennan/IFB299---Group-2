<script src="http://maps.googleapis.com/maps/api/js"></script>
                <script>
                function initialize() {
                  var mapProp = {
                    center:new google.maps.LatLng(<?php echo $park["Latitude"]?>,<?php echo $park["Longitude"]?>),
                    zoom:17,
                    mapTypeId:google.maps.MapTypeId.ROADMAP,
                  };
                  var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
                }
                google.maps.event.addDomListener(window, 'load', initialize);
                showPosition(center);
                </script>
                <script>
                function showPosition(position) {
                    document.getElementById("status").innerHTML = "Latitude: " + position.coords.latitude + ", Longitude: " + position.coords.longitude;

                    // display on a map
                    var latlon = position.coords.latitude + "," + position.coords.longitude;
                    var img_url = "http://maps.googleapis.com/maps/api/staticmap?center="+latlon+"&zoom=14&size=400x300&sensor=false";
                    document.getElementById("googleMap").innerHTML = "<img src='"+img_url+"'>";
                }
                </script>
                
                https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3542.8609809917643!2d153.03651181566602!3d-27.380056719452874!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjfCsDIyJzQ4LjIiUyAxNTPCsDAyJzE5LjMiRQ!5e0!3m2!1sen!2sau!4v1464586136289

<script>
                function getLocation() { 
                    if (navigator.geolocation) { 
                          navigator.geolocation.getCurrentPosition(showPosition, showError); 
                    } else { 
                          document.getElementById("status").innerHTML="Geolocation is not supported by this browser."; 
                    } 
                    if (typeof(Number.prototype.toRad) === "undefined") { 
                        Number.prototype.toRad = function() {  
                        return this * Math.PI / 180;  
                        }  
                    }
                } 
                function showError(error) { 
                    var msg = ""; 
                    switch(error.code) { 
                          case error.PERMISSION_DENIED: 
                                msg = "User denied the request for Geolocation."
                                break; 
                          case error.POSITION_UNAVAILABLE: 
                                msg = "Location information is unavailable." 
                                break; 
                          case error.TIMEOUT: 
                                msg = "The request to get user location timed out." 
                                break; 
                          case error.UNKNOWN_ERROR: 
                                msg = "An unknown error occurred." 
                                break; 
                    } 
                    document.getElementById("status").innerHTML = msg;
                } 
                </script>