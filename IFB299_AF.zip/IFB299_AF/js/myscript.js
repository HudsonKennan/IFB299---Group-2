function validate() {
  
  return checkName();
  
}

function checkName() {
  
  var user = document.getElementById('username');
  
  if(user.value == "") {
    return false;
  }
  
}