<!DOCTYPE html>

        <?php
            $con = mysql_connect('localhost' ,'root' ,'');
            $db = mysql_select_db('redhouse');
        
        if(isset($_POST['update'])){
        $Updatequery = "UPDATE users SET fname='$_POST[namef]', lname='$_POST[namel]', email='$_POST[email]', dob='$_POST[dob]', gender='$_POST[gender]', renting='$_POST[renting]', address='$_POST[address]', phno='$_POST[phno]'  WHERE userID='$_POST[hidden]'";
        mysql_query($Updatequery, $con);
        };
          
        ?>

<html>
<head>
    <title>Red House Real Estate</title>
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,700|Squada+One" rel="stylesheet">
</head>

<body>
    <div id="header">
        <img src="img/RHRE%20Logo.svg" alt="Red House Rentals Logo"/>
        <div id="login">
            <a href="login.php">login</a>|<a href="register.php">register</a>|<a href="register.php">Settings</a>|<a href="register.php">MyProperties</a>
        </div>
    </div>
    
    <div id="nav_menu">
        <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="search.php">Search</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </div>
    
    <!--create main content area-->
    <div id="content">
        <div id="form">
            <form method="post" id="registration">
                <fieldset>
                    <legend>Account Settings</legend>
                    <p>All fields are required unless stated otherwise</p>
                    <table>
                        
                        <tr><td><label>First Name:</label></td>

                    
                        <tr>
                            <td><label>Last Name:</label></td>
                            <td><input id="lname" type="text" name="lname" size="40" maxlength="50" required/></td>
                        </tr>
                        <tr>
                            <td><label>Gender:</label></td>
                            <td>
                                <select name="gender" id="gender">
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="N/A">Rather Not say</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td><label>Password:</label></td>
                            <td><input type="password" name="password" placeholder="*******" onchange="passwordconf.pattern = this.value" size="40" required/></td><!--password input parameters as well as client-side validation to ensure password is entered the same in both the password and confirm password fields-->
                        </tr>
                        <tr>
                            <td><label>Confirm Password:</label></td>
                            <td><input id="passwordconf" type="password" placeholder="*******" name="passwordconf" size="40" required/></td>
                        </tr>
                        <tr>
                            <td><label>Email:</label></td>
                            <td><input type="email" name="email" size="40" maxlength="50" placeholder="email@address.com" onchange="emailconf.pattern = this.value" pattern="*@*\.*" required/></td>
                            <!--email input field parameters as well as client-side validation to ensure email is entered correctly in both the email and confirm email fields-->
                        </tr>
                        <tr>
                            <td><label>Phone Number:</label></td>
                            <td><input type="phone_number" id="PHNO" name="PHNO" size="40" maxlength="12" required/></td>
                        </tr>
                        <!--<tr>
                            <td><label>D.O.B.:</label></td>
                            <td><select name="dob_day" required>
                                </select>
                                /
                                <select name="dob_month" required>
                                    
                                </select>
                                /
                                <select name="dob_year" required>
                                    
                                </select></td>
                        </tr>-->
                        <tr>
                            <td></td>
                            <td><input type="submit" name="submit" value="Update"/></td>
                            <!--submit the entered information for analysis and if it passes, the information is added to the database-->
                        </tr>
                    </table>
                </fieldset>
            </form>
            <?php
            if (isset($_POST['submit']))
                {
                    $fname = $_POST['fname'];
                    $lanme = $_POST['lname'];
                    $gender = $_POST['gender'];
                    $password = $_POST['password'];
                    $email = $_POST['email'];
                    $PHNO = $_POST['PHNO'];
                
                $dbh= "INSERT INTO users(fname, lname, gender, password, email, PHNO) VALUES ('$fname', '$lname', '$gender', '$password', '$email', '$PHNO')";
                echo $sql;
                $_SESSION['message']="Blog Post Added";	
                }
			?>
        </div>
<br>
        </br>
                
            </div>
        </div>
        
    </div>
        
        
    
    <div id="footer">
        <p><a href="index.php">Home</a>|<a href="about.php">About</a></p>
        <p>This website was created by Connor Nicholls, Hudson Kennan, Jessica Cockett and Phyllis Yaw for IFB299<br>
        Tutor: Prakash Bhandari, 12-2pm Wednesday</p>
    </div>

</body>
</html>
