<!DOCTYPE html>

<html>
<head>
    <title>Red House Real Estate | Search Results</title>
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Nunito:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>

<body>
<?php
    require("common.php");
    include 'menu.inc'
?>

<div id="content">
    <div id="results">
        <h2>Your Search Results</h2>
        <!--insert information inputed into search form-->
        <p>Suburb: 
        <?php
        if($_POST["suburb"] == '*') {
            echo "No Suburb Specified";
        } else {
            echo $_POST["suburb"];
        } ?></p>
        
        <!--Table of results-->
        <table><tr>
        <td><h3>Property ID</h3></td>
        <td><h3>Suburb</h3></td>
        <td><h3>Property Type</h3></td>
        <td><h3>Furnished</h3></td>
        <td><h3>Weekly Rent ($)</h3></td></tr>

        <?php 
        $pdo = new PDO('mysql:host=localhost;dbname=phyllisy_rhre', 'phyllisy_ifb299', 'Miggles_3');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        try {
            $query_string = "SELECT property_id, suburb, property_type, furnished, property_rent FROM ifb299.properties WHERE property_id LIKE '%".$_POST["property_id"]."%' AND suburb = '".$_POST["suburb"]."' AND property_type = '".$_POST["property_type"]."' AND furnished = '".$_POST["furnished"]."' AND property_rent <= '".$_POST["property_rent"]."' AND property_available = 'Yes' ORDER BY property_id";
            $result = $pdo->query($query_string);
            foreach ($result as $properties) {
                echo ('<tr><td><a href="search_result_item.php?property='.$properties['property_id'].'" onclick="document.forms[\'search\'].submit();">'.$properties['property_id'].'</a></td><td>'.$properties['suburb'].'</td><td>'.$properties['property_type'].'</td><td>'.$properties['furnished'].'</td><td>'.$properties['property_rent'].'</td></tr>');
            }
        }
        
        catch (PDOException $e) {
            echo $e->getMessage();
        }
        ?>

        </table>
    </div>
</div>

<?php include 'footer.inc' ?>

</body>
</html>
