<!DOCTYPE html>
    
<html>
<head> <!--head of html-->
    <title>Red House Real Estate | Register</title>
    <meta charset="UTF-8"/> <!--set preferred character set-->
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/> <!--link CSS stylesheet-->
    <link href='https://fonts.googleapis.com/css?family=Nunito:700%7COpen+Sans:400,700' rel='stylesheet' type='text/css'> <!--link font choices-->
</head>

<?php
    //execute common.php to connect to the database and start a session
    require("common.php");
    
    //check if the registration form has been submitted. If yes,the registration code is run, otherwise the form is displayed
    if(!empty($_POST)) {
        if(empty($_POST['f_name'])) {
            die("Please enter your first name"); //check if a first name has been entered
        }
        if(empty($_POST['l_name'])) {
            die("Please enter your last name"); //check if a last name has been entered
        }
        if(empty($_POST['password'])) {
            die("Please enter a password"); //check if a password has been entered
        }
        if(empty($_POST['email'])) {
            die("Please enter an email");
        }
        
        $query = "SELECT 1 FROM users WHERE email = :email"; //check email hasn't already been used
        $query_params = array(':email' => $_POST['email']); 
        
        try {
            $statement = $db->prepare($query);
            $result = $statement->execute($query_params);
        }
        catch(PDOException $ex) {
            die("Failed to run query: " . $ex->getMessage());
        }
        
        $row = $statement->fetch();
        if($row) {
            die("This email address is already registered"); //Error message if the email has already been used
        }
        
        $query = "INSERT INTO users (f_name, l_name, gender, password, email, phone_number, dob, tc, sub) VALUES (:f_name, :l_name, :gender, :password, :email, :phone_number, :dobstring, :terms, :subscribe)"; //mySQL insert string for adding the user's registration details to the database
        
        $dobstring = $_POST["dob_year"] . "-" . $_POST["dob_month"] . "-" . $_POST["dob_day"]; //combine individual date of birth information into one string
        
        $password = $_POST['password'];
        
        for($round = 0; $round < 100; $round++) {
            $password = $password;
        }
        
        $query_params = array(':f_name' => $_POST['f_name'], ':l_name' => $_POST['l_name'], ':gender' => $_POST['gender'], ':password' => $password, ':email' => $_POST['email'], ':phone_number' => $_POST['phone_number'],  ':dobstring' => $dobstring, ':terms' => $_POST['terms'], ':subscribe' => $_POST['subscribe']); //set values of information to be entered into database
        
        try {
            $statement = $db->prepare($query);
            $result = $statement->execute($query_params);
        }
        catch(PDOException $ex) {
            die("Failed to run query: " . $ex->getMessage());
        }
        
        header("Location: login.php");
        
        die("Redirecting to login.php"); //redirect the user to the login page
    }
?>

<body>
    <?php include 'menu.inc' ?>
    
    <!--create main content area-->
    <div id="content">
        <div id="form">
            <form action="register.php" method="post" id="registration">
                <fieldset>
                    <legend>Register</legend>
                    <p>All fields are required unless stated otherwise</p>
                    <table>
                        <tr>
                            <td><label>First Name:</label></td>
                            <td><input id="f_name" type="text" name="f_name" size="20" maxlength="50" required/></td>
                        </tr>
                        <tr>
                            <td><label>Last Name:</label></td>
                            <td><input id="l_name" type="text" name="l_name" size="20" maxlength="50" required/></td>
                        </tr>
                        <tr>
                            <td><label>Gender:</label></td>
                            <td><input type="radio" id="gender" name="gender" value="male" required>Male
                                <input type="radio" id="gender" name="gender" value="female" required>Female
                                <input type="radio" id="gender" name="gender" value="other" required>Prefer not to say</td>
                        </tr>
                        <tr>
                            <td><label>Password:</label></td>
                            <td><input type="password" name="password" onchange="passwordconf.pattern = this.value" required/></td><!--password input parameters as well as client-side validation to ensure password is entered the same in both the password and confirm password fields-->
                        </tr>
                        <tr>
                            <td><label>Confirm Password:</label></td>
                            <td><input id="passwordconf" type="password" name="passwordconf" required/></td>
                        </tr>
                        <tr>
                            <td><label>Email:</label></td>
                            <td><input type="email" name="email" size="20" maxlength="50" placeholder="email@address.com" onchange="emailconf.pattern = this.value" pattern="*@*\.*" required/></td>
                            <!--email input field parameters as well as client-side validation to ensure email is entered correctly in both the email and confirm email fields-->
                        </tr>
                        <tr>
                            <td>Confirm Email:</td>
                            <td><input id="emailconf" type="text" name="emailconf" size="20" maxlength="50" placeholder="email@address.com" required/></td>
                        </tr>
                        <tr>
                            <td><label>Phone Number:</label></td>
                            <td><input type="phone_number" name="phone_number" size="20" maxlength="12" required/></td>
                        </tr>
                        <tr>
                            <td><label>D.O.B.:</label></td>
                            <td><select name="dob_day" required><!--dropdown menu DOB options-->
                                    <?php 
                                    for ($i = 31; $i >= 01 ; $i--) { 
                                        echo "<option value=\"$i\">$i</option>";
                                    } ?>
                                </select>
                                /
                                <select name="dob_month" required>
                                    <?php 
                                    for ($i = 12; $i >= 01 ; $i--) { 
                                        echo "<option value=\"$i\">$i</option>";
                                    } ?>
                                </select>
                                /
                                <select name="dob_year" required>
                                    <?php 
                                    for ($i = 2017; $i >= 1900 ; $i--) { 
                                        echo "<option value=\"$i\">$i</option>";
                                    } ?>
                                </select></td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="terms" value="Y" required></td>
                            <td>I have read and accept the <a href="#">Terms and Conditions</a></td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="subscribe" value="Y" checked></td>
                            <td>I would like to receive newsletters from Park Search</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="submit" value="Submit"/></td>
                            <!--submit the entered information for analysis and if it passes, the information is added to the database-->
                        </tr>
                    </table>
                </fieldset>
            </form>
        </div>
    </div>
    
    <?php include 'footer.inc' ?><!--include footer-->

</body>
</html>
