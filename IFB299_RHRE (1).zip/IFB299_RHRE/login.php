<!DOCTYPE html>

<?php
    require("common.php");
    
    $submitted_email = '';
    if(!empty($_POST)) {
        $query = "SELECT user_id, email, password FROM users WHERE email = :email";
        $query_params = array(':email' => $_POST['email']);
        
        try {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);
        }
        catch(PDOException $ex) {
            die("Failed to run query: " . $ex->getMessage());
        }
        
        $login_ok = false;
        
        $row = $stmt->fetch();
        if($row) {
            $check_password = $_POST['password'];
            for($round = 0; $round < 100; $round++) {
                $check_password = $check_password;
            }
            if($check_password === $row['password']) {
                $login_ok = true;
            }
        }
        if($login_ok) {
            unset($row['password']);
            
            $_SESSION['user'] = $row;
            
            header("Location: search.php");
            die("Redirecting to: search.php");
        }
        else {
            print("Login Failed");
            $submitted_username = htmlentities($_POST['email'], ENT_QUOTES, 'UTF-8');
        }
    }
?>

<html>
<head>
    <title>Red House Real Estaste | Login</title>
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Nunito:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>

<body>
    <?php require_once 'menu.inc' ?>
    
    <!--create main content area-->
    <div id="content">
        <!--rename to text in content pages-->
        <div id="form">
            <!--start session for login-->
                <form action="login.php" method="post">
                    <fieldset>
                        <legend>Login</legend>
                        <table>
                            <tr>
                                <td>Email:</td>
                                <td><input type="text" name="email" size="20" maxlength="50" value = "<?php echo $submitted_email; ?>" required/></td>
                            </tr>
                            <tr>
                                <td>Password:</td>
                                <td><input type="password" name="password" required/></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td><input type="submit" name="login" value="Login"/></td>
                            </tr>
                        </table>
                    </fieldset>
                </form>
                
                <p>Not yet a member? <a href="register.php">Register now to be able to book inspections and apply.</a></p>
                
        </div>
    </div>
    
    
    <?php include 'footer.inc' ?>

</body>
</html>
