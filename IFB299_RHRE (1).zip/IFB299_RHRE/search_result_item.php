<!DOCTYPE html>

<html>
<head>
    <title>Red House Real Estate</title><!-- add property id here?-->
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Nunito:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>

<body>
    <?php
        require("common.php");
        include 'menu.inc'
    ?>
    
    <div id="content">
        <div id="image">
            <!--insert images of property, php pull of image names from database-->
        </div>
        <div id="property_info">
            <fieldset>
                <?php 
                $pdo = new PDO('mysql:host=localhost;dbname=phyllisy_rhre', 'phyllisy_ifb299', 'Miggles_3');
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                try {
                    $result = $pdo->query("SELECT property_id, suburb, property_rent, furnished, address, bed, bath, garage FROM ifb299.properties WHERE property_id = '".$_GET["property_id"]."'");
                    foreach ($result as $properties) {
                        echo "<legend>".$properties['headline']."</legend>";
                    }
                ?>
                <h3>Location:</h3>
                <p><?php echo $properties['address'].", ".$properties['suburb'] ?></p>


                    <?php 
                    $pdo = new PDO('mysql:host=localhost;dbname=phyllisy_rhre', 'phyllisy_ifb299', 'Miggles_3');
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    try {
                        //$pdo->beginTransaction();
                        //$insert_string = "INSERT INTO reviews () VALUES ();";
                        //$pdo->exec($insert_string);
                        //$pdo->commit();
                    }
                    catch (PDOException $e) {
                        echo $e->getMessage();
                        //$pdo->rollback();
                    }
                    ?>

            </fieldset>
        </div>
        
        <div id="scheduling">
            
        </div>
        
        
    </div>
    
    <?php include 'footer.inc' ?>

</body>
</html>
