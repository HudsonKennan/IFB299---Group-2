<!DOCTYPE html>

<html>
<head>
    <title>Red House Real Estate | About</title>
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Nunito:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>

<body>
    <?php include 'menu.inc' ?>
    
    <!--create main content area-->
    <div id="content">
        <!--rename feature to image in content pages-->
        <div id="text">
            <h2>About Us</h2>
            <p>Red House Real Estate was created by Connor Nicholls, Hudson Kennan, Jessica Cockett and Phyllis Yaw as part of the project requirements of IFB299, Application design and Development in Semester 1, 2017 at the Queensland University of Technology.<br/>
            </p>
        </div>
    </div>
    
    <?php include 'footer.inc' ?>
</body>
</html>
