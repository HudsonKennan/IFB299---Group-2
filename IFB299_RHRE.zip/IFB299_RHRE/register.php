<!DOCTYPE html>
    
<html>
<head> <!--head of html-->
    <title>Red House Real Estate</title>
    <meta charset="UTF-8"/> <!--set preferred character set-->
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/> <!--link CSS stylesheet-->
    <link href='https://fonts.googleapis.com/css?family=Nunito:700%7COpen+Sans:400,700' rel='stylesheet' type='text/css'> <!--link font choices-->
</head>

<?php
    //execute common.php to connect to the database and start a session
    require("common.php");
    
    //check if the registration form has been submitted. If yes,the registration code is run, otherwise the form is displayed
    if(!empty($_POST)) {
        if(empty($_POST['f_name'])) {
            die("Please enter your first name"); //check if a first name has been entered
        }
        if(empty($_POST['l_name'])) {
            die("Please enter your last name"); //check if a last name has been entered
        }
        if(empty($_POST['password'])) {
            die("Please enter a password"); //check if a password has been entered
        }
        if(empty($_POST['email'])) {
            die("Please enter an email");
        }
        /*$query = "SELECT 1 FROM members WHERE username = :username"; //query database for usernames already in use
        $query_params = array(':username' => $_POST['username']); //see if any of the queried usernames match the username entered
        
        try {
            $statement = $db->prepare($query);
            $result = $statement->execute($query_params);
        }
        catch(PDOException $ex) {
            die("Failed to run query: " . $ex->getMessage()); //Display message if the query isn't able to complete
        }
        
        $row = $statement->fetch();
        if($row) {
            die("This username is already in use"); //Display message if the username is already taken
        }*/
        
        $query = "SELECT 1 FROM members WHERE email = :email"; //query database for emails already in use matching the one entered
        $query_params = array(':email' => $_POST['email']); 
        
        try {
            $statement = $db->prepare($query);
            $result = $statement->execute($query_params);
        }
        catch(PDOException $ex) {
            die("Failed to run query: " . $ex->getMessage());
        }
        
        $row = $statement->fetch();
        if($row) {
            die("This email address is already registered"); //Display message to user if the email has already been registered
        }
        
        $query = "INSERT INTO members (f_name, l_name, gender, password, salt, email, DOB, TC, sub) VALUES (:f_name, :l_name, :gender, :password, :salt, :email, :dobstring, :terms, :subscribe)"; //mySQL insert string for adding the user's registration details to the database
        
        $salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647)); //salt info
        
        $dobstring = $_POST["dob_year"] . "-" . $_POST["dob_month"] . "-" . $_POST["dob_day"]; //combine individual date of birth information into one string
        
        $password = hash('sha256', $_POST['password'] . $salt); //hash the password using SHA2 encryption SHA256
        
        for($round = 0; $round < 65536; $round++) {
            $password = hash('sha256', $password . $salt);
        }
        
        $query_params = array(':f_name' => $_POST['f_name'], ':l_name' => $_POST['l_name'], ':gender' => $_POST['gender'], ':password' => $password, ':salt' => $salt, ':email' => $_POST['email'], ':dobstring' => $dobstring, ':terms' => $_POST['terms'], ':subscribe' => $_POST['subscribe']); //set values of information to be entered into database
        
        try {
            $statement = $db->prepare($query);
            $result = $statement->execute($query_params);
        }
        catch(PDOException $ex) {
            die("Failed to run query: " . $ex->getMessage());
        }
        
        header("Location: login.php");
        
        die("Redirecting to login.php"); //upon registration going through, redirect the user to the login page so they may log in
    }
?>

<body>
    <?php include 'menu.inc' ?><!--include header and navigation menu, contained in a separate menu.inc file-->
    
    <!--create main content area-->
    <div id="content">
        <!--rename to text in content pages-->
        <div id="register">
            <!--insert registration fields-->
            <form action="register.php" method="post" id="registration"><!--begin form. Using HTML5 validation-->
                <fieldset><!--keep everything within a fieldset to assist with visual hierarchy. Not particularly necessary on this page due to there only being one body of content-->
                    <legend>Register</legend><!--used as a kind of heading, helps with skimming-->
                    <p>All fields are required unless stated otherwise</p> <!--minor instructions given-->
                    <table>
                        <tr>
                            <td><label>First Name:</label></td><!--request username-->
                            <td><input id="f_name" type="text" name="f_name" size="20" maxlength="50" required/></td><!--username input parameters-->
                        </tr>
                        <tr>
                            <td><label>Last Name:</label></td><!--request username-->
                            <td><input id="l_name" type="text" name="l_name" size="20" maxlength="50" required/></td><!--username input parameters-->
                        </tr>
                        <tr>
                            <td><label>Gender:</label></td><!-- request gender-->
                            <td><input type="radio" id="gender" name="gender" value="male" required>Male<!--gender selected using radio buttons, parameters shown. Value is what will be entered into the database-->
                                <input type="radio" id="gender" name="gender" value="female" required>Female
                                <input type="radio" id="gender" name="gender" value="other" required>Other</td>
                        </tr>
                        <tr>
                            <td><label>Password:</label></td><!--request password-->
                            <td><input type="password" name="password" onchange="passwordconf.pattern = this.value" required/></td><!--password input parameters as well as client-side validation to ensure password is entered the same in both the password and confirm password fields-->
                        </tr>
                        <tr>
                            <td><label>Confirm Password:</label></td><!--request confirmation of password-->
                            <td><input id="passwordconf" type="password" name="passwordconf" required/></td>
                        </tr>
                        <tr>
                            <td><label>Email:</label></td><!--request email-->
                            <td><input type="email" name="email" size="20" maxlength="50" placeholder="email@address.com" onchange="emailconf.pattern = this.value" pattern="*@*\.*" required/></td><!--email input field parameters as well as client-side validation to ensure email is entered correctly in both the email and confirm email fields-->
                        </tr>
                        <tr>
                            <td>Confirm Email:</td><!--request confirmation of email-->
                            <td><input id="emailconf" type="text" name="emailconf" size="20" maxlength="50" placeholder="email@address.com" required/></td>
                        </tr>
                        <tr>
                            <td><label>D.O.B.:</label></td><!--request date of birth-->
                            <td><select name="dob_day" required><!--dropdown menu DOB options-->
                                    <?php 
                                    for ($i = 31; $i >= 01 ; $i--) { 
                                        echo "<option value=\"$i\">$i</option>";
                                    } ?>
                                </select>
                                /
                                <select name="dob_month" required>
                                    <?php 
                                    for ($i = 12; $i >= 01 ; $i--) { 
                                        echo "<option value=\"$i\">$i</option>";
                                    } ?>
                                </select>
                                /
                                <select name="dob_year" required>
                                    <?php 
                                    for ($i = 2016; $i >= 1900 ; $i--) { 
                                        echo "<option value=\"$i\">$i</option>";
                                    } ?>
                                </select></td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="terms" value="Y" required></td><!--request acceptance of the terms and conditions of using the Park Search service-->
                            <td>I have read and accept the <a href="#">Terms and Conditions</a></td><!--use of checkbox, also Terms and conditions doesn't take you anywhere-->
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="subscribe" value="Y" checked></td><!--optional checkbox for users to tick to allow park Search to email them regarding changes/news/miscellaneous-->
                            <td>I would like to receive newsletters from Park Search</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="submit" value="Submit"/></td><!--submit button. clicking it will submit the entered information for analysis and if it passes, the information will be added into the database-->
                        </tr>
                    </table>
                </fieldset>
            </form>
        </div>
    </div>
    
    <?php include 'footer.inc' ?><!--include footer, which is kept in a separate include file-->

</body>
</html>
