<!DOCTYPE html>

<html>
<head>
    <title>Search | Red House Real Estate</title>
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Nunito:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>

<body>
    <?php include 'menu.inc' ?>
    
    <!--create main content area-->
    <div id="content">
        <div id="search">
            <!--insert front page search fields here. Same as on search page, just on the front page as well-->
            <!--<?php include 'search_form.inc' ?>-->
            <form action="search_result.php" method="post" >
                <fieldset>
                    <legend>Search</legend>
                    <table>
                        <tr>
                            <td><label>Property ID:</label></td>
                            <td><input type="text" name="property_id" size="15" maxlength="50"/></td>
                        </tr>
                        <tr>
                            <td><label>Suburb:</label></td>
                            <td><select name="suburb" id="suburb">
                            <option value="*"> </option> <!-- don't search using suburb, default setting-->
                            <!--<?php
                            $pdo = new PDO('mysql:host=fastapps04.qut.edu.au;dbname=n9395130', 'n9395130', 'password1');
                            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            try {
                                $result = $pdo->query('SELECT DISTINCT Suburb FROM n9395130.items ORDER BY Suburb');
                            }
                            catch (PDOException $e) {
                                echo $e->getMessage();
                            }
                            foreach ($result as $parks) {
                                echo '<option value="'.$parks['Suburb'].'">'.$parks['Suburb'].'</option>';
                            }
                            ?>-->

                            </select></td>
                        </tr>
                        <tr>
                            <td><label>Weekly Rent:</label></td>
                            <td>
                            <p>Up to</p><br>
                            <input type="checkbox" name="rent" value="300" checked="checked"/> $300
                            <input type="checkbox" name="rent" value="400" checked="checked"/> $400
                            <input type="checkbox" name="rent" value="400<=500" checked="checked"/> $500
                            <input type="checkbox" name="rent" value="500<=600" checked="checked"/> $600
                            <input type="checkbox" name="rent" value=">600" checked="checked"/> $600+</td>
                        </tr>
                        <tr>
                            <td><label>Property Type:</label></td>
                            <td>
                            <input type="checkbox" name="p_type" value="house" checked="checked"/> House
                            <input type="checkbox" name="p_type" value="townhouse" checked="checked"/> Townhouse
                            <input type="checkbox" name="p_type" value="apartment" checked="checked"/> Apartment & Unit
                            <input type="checkbox" name="p_type" value="villa" checked="checked"/> Villa
                            <input type="checkbox" name="p_type" value="retirement" checked="checked"/> Retirement Living</td>
                        </tr>
                        <tr>
                            <td><label>Furnishings:</label></td>
                            <td>
                            <input type="radio" name="furnish" value="yes"/> Yes
                            <input type="radio" name="furnish" value="no"/>No</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="submit" value="Submit"/></td>
                        </tr>
                    </table>
                </fieldset>
            </form>
        </div>
    </div>
    
    <?php include 'footer.inc' ?>

</body>
</html>
