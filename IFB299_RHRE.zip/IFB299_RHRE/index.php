<!DOCTYPE html>

<html>
<head>
    <title>Red House Real Estate</title>
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Nunito:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>

<body>
    <?php include 'menu.inc' ?>
    
    <!--create main content area-->
    <div id="content">
        <!--rename feature to image in content pages-->
        <div id="image">
            <img src="img/pexels-photo-186077.jpeg" alt="Image of House" width=940px height=419px/>
            <!--insert css animated banner here (scrolls through featured parks of that week, etc.)-->
        </div>
        <!--rename to text in content pages-->
        <div id="search">
            <!--insert front page search fields here. Same as on search page, just on the front page as well-->
            <?php include 'search_form.inc' ?>
        </div>
        <div id="update">
            
        </div>
    </div>
    
    <?php include 'footer.inc' ?>

</body>
</html>
