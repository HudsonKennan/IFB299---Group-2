<!DOCTYPE html>

<?php
    require("common.php");
    
    $submitted_email = '';
    if(!empty($_POST)) {
        $query = "SELECT id, email, password, salt FROM members WHERE email = :email";
        $query_params = array(':email' => $_POST['email']);
        
        try {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);
        }
        catch(PDOException $ex) {
            die("Failed to run query: " . $ex->getMessage());
        }
        
        $login_ok = false;
        
        $row = $stmt->fetch();
        if($row) {
            $check_password = hash('sha256', $_POST['password'] . $row['salt']);
            for($round = 0; $round < 65536; $round++) {
                $check_password = hash('sha256', $check_password . $row['salt']);
            }
            if($check_password === $row['password']) {
                $login_ok = true;
            }
        }
        if($login_ok) {
            unset($row['salt']);
            unset($row['password']);
            
            $_SESSION['user'] = $row;
            
            header("Location: search.php");
            die("Redirecting to: search.php");
        }
        else {
            print("Login Failed");
            $submitted_username = htmlentities($_POST['email'], ENT_QUOTES, 'UTF-8');
        }
    }
?>

<html>
<head>
    <title>Park Search</title>
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Nunito:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>

<body>
    <?php require_once 'menu.inc' ?>
    
    <!--create main content area-->
    <div id="content">
        <!--rename to text in content pages-->
        <div id="login_page">
            <!--start session for login-->
                <form action="login.php" method="post">
                    <fieldset>
                        <legend>Login</legend>
                        <table>
                            <tr>
                                <td>Email:</td>
                                <td><input type="text" name="email" size="20" maxlength="50" value = "<?php echo $submitted_email; ?>" required/></td>
                            </tr>
                            <tr>
                                <td>Password:</td>
                                <td><input type="password" name="password" required/></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td><input type="submit" name="login" value="Login"/></td>
                            </tr>
                        </table>
                    </fieldset>
                </form>
                
                <p>Not already a member? <a href="register.php">Register Now</a></p>
                
        </div>
    </div>
    
    
    <?php include 'footer.inc' ?>

</body>
</html>
