<!DOCTYPE html>

<html>
<head>
    <title>Red House Real Estate</title>
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Nunito:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>

<body>
    <?php include 'menu.inc' ?>
    
    <!--create main content area-->
    <div id="content">
        <!--rename feature to image in content pages-->
        <div id="text">
            <h2>About Us</h2>
            <p>Red House Real Estate was created by Connor Nicholls, Hudson Kennan, Jessica Cockett and Phyllis Yaw as part of the project requirements of IFB299, Application design and Development in Semester 1, 2017 at the Queensland University of Technology.<br/>
            The site utilises HTML5, CSS3, and Javascript for the client-side of the site, and PHP and MySQL for the server-side of the site. The primary resources used in the creation of the site were the "HTML & CSS: Design and build websites" and "JavaScript and jQuery" books by Jon Duckett as well as knowledge acquired through resources such as Lynda.com and the prior knowledge acquired by the aforementioned team members  along with knowledge acquired through a number of different subjects.</p>
        </div>
    </div>
    
    <?php include 'footer.inc' ?>
</body>
</html>
