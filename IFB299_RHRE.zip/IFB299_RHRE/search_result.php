<!DOCTYPE html>

<html>
<head>
    <title>Park Search</title>
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Nunito:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>

<body>
<?php
    require("common.php");
    include 'menu.inc'
?>
<!--create main content area-->
<div id="content">
    <!--rename feature to image in content pages, rename to results in search results page-->
    <div id="results">
        <h2>Your Search Results For...</h2>
        <!--insert information inputed into search form-->
        <p>Suburb: 
        <?php
        if($_POST["suburb"] == 'LOCATION') {
            echo "YOUR LOCATION";
        } else if($_POST["suburb"] == '*') {
            echo "No Suburb Specified";
        } else {
            echo $_POST["suburb"];
        } ?></p>
        
        <!--Google Map showing location of parks-->
        
        
        <!--Table of results-->
        <table><tr>
        <td><h3>Name</h3></td>
        <td><h3>Suburb</h3></td>
        <td><h3>Location</h3></td>
        <td><h3>Rating</h3></td></tr>

        <?php 
        $pdo = new PDO('mysql:host=fastapps04.qut.edu.au;dbname=n9395130', 'n9395130', 'password1');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        try {
            $query_string = "SELECT ParkID, ParkName, Suburb, Street, Rating FROM n9395130.items LEFT JOIN n9395130.reviews ON items.ParkCode = reviews.ParkCode WHERE Parkname LIKE '%".$_POST["park_name"]."%' AND Suburb = '".$_POST["suburb"]."' AND (Rating >= ".$_POST["rating"]." OR Rating IS NULL) ORDER BY Suburb, CASE WHEN Rating IS NULL THEN 1 ELSE 0 END, Rating DESC, ParkName";
            $result = $pdo->query($query_string);
            foreach ($result as $parks) {
                //echo '<option value="'.$parks['Suburb'].'">'.$parks['Suburb'].'</option>';
                echo ('<tr><td><a href="search_result_item.php?parkcode='.$parks['ParkID'].'" onclick="document.forms[\'search\'].submit();">'.$parks['ParkName'].'</a></td><td>'.$parks['Suburb'].'</td><td>'.$parks['Street'].'</td><td>');
                if ($parks['Rating']) {
                    echo $parks['Rating'].'</td></tr>';
                } else {
                    echo 'N/A</td></tr>';
                }
            }
        }
        
        catch (PDOException $e) {
            echo $e->getMessage();
        }
        ?>

        </table>
    </div>
</div>

<?php include 'footer.inc' ?>

</body>
</html>
