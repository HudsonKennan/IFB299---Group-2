<!DOCTYPE html>

<html>
<head>
    <title>Park Search</title>
    <meta charset="UTF-8"/>
    <link href="normalize.css" type="text/css" rel="stylesheet"/>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Nunito:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
</head>

<body>
    <?php include 'menu.inc' ?>
    
    <!--create main content area-->
    <div id="content">
        <!--rename feature to image in content pages-->
        <div id="image">
            <!--insert image of park if available-->
            <img src="img/mccaskiepark.jpg" alt="Image of McCaskie Park" width=940px height=419px/>
        </div>
        <!--rename to text in content pages-->
        <div id="text">
            <fieldset>
                <?php 
                $pdo = new PDO('mysql:host=fastapps04.qut.edu.au;dbname=n9395130', 'n9395130', 'password1');
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                try {
                    $result = $pdo->query("SELECT ParkName, Street, Suburb, Latitude, Longitude FROM n9395130.parks WHERE ParkCode = '".$_GET["parkcode"]."'");
                    foreach ($result as $park) {
                        echo "<legend>".$park['ParkName']."</legend>";
                    }
                    $latlon_string = $park['Latitude'].",".$park['Longitude'];
                    echo $latlon_string;
                ?>
                <!--insert location details here (i.e. address, etc.). Include google maps inset (640x300)-->
                <h3>Location:</h3>
                <p><?php echo $park['Street'].", ".$park['Suburb'] ?></p>
                <!--<div id="mapholder"></div>-->
                <div id="googleMap" style="width:500px;height:380px;"></div>

                <script src="http://maps.googleapis.com/maps/api/js"></script>
                <script>
                function initialize() {
                    var mapProp = {
                        center:new google.maps.LatLng(<?php echo $park["Latitude"]?>,<?php echo $park["Longitude"]?>),
                        zoom:17,
                        mapTypeId:google.maps.MapTypeId.ROADMAP
                    };
                    var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);

                });
                }
                google.maps.event.addDomListener(window, 'load', initialize);
                showPosition(center);
                </script>
                <script>
                function showPosition(position) {
                    document.getElementById("status").innerHTML = "Latitude: " + position.coords.latitude + ", Longitude: " + position.coords.longitude;

                    // display on a map
                    var latlon = position.coords.latitude + "," + position.coords.longitude;
                    var img_url = "http://maps.googleapis.com/maps/api/staticmap?center="+latlon+"&zoom=14&size=400x300&sensor=false";
                    document.getElementById("googleMap").innerHTML = "<img src='"+img_url+"'>";
                    
                }
                </script>
                
                <?php
                }
                catch (PDOException $e) {
                    echo $e->getMessage();
                }
                ?>

                <h2>Add a Review</h2>
                    <form action="search_result_item.php" method="post">
                        <table>
                            <tr>
                                <td><h3>Rating:</h3></td>
                                <td><input type="radio" name="rating" value="1"/>1
                                    <input type="radio" name="rating" value="2"/>2
                                    <input type="radio" name="rating" value="3"/>3
                                    <input type="radio" name="rating" value="4"/>4
                                    <input type="radio" name="rating" value="5"/>5</td>
                            </tr>
                            <tr>
                                <td><h3>Title:</h3></td>
                                <td><input type="text" name="review_title"size="20" maxlength="150"></input></td>
                            </tr>
                            <tr>
                                <td><h3>Comment:</h3></td>
                                <td><textarea name="review" cols="75" rows="7"></textarea></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td><input type="submit" name="submit" value="Submit"/></td>
                            </tr>
                        </table>
                    </form>
                    
                    <div id="reviews">
                        <h2>Reviews</h2>
                        
                        <?php
                        $reviews = $pdo->query("SELECT Title, Username, Rating, Comment FROM n9395130.reviews WHERE ParkID = '".$_GET["ParkID"]."'");
                        
                        foreach ($reviews as $review) {
                            echo "<legend>".$review['ParkName']."</legend>";
                        ?>
                        
                        <table>
                            <tr>
                                <td><img src="img/user.png" alt="User Image" width=100px height=100px/></td>
                                <td><h3><?php echo $Title; ?></h3></td>
                            </tr>
                            <tr>
                                <td><h4><?php echo $Username; ?></h4></td>
                                <td><?php echo $Comment; ?></td>
                            </tr>
                            <tr>
                                <td><h4>Rating:</h4></td>
                                <td><?php echo $Rating; ?></td>
                            </tr>
                        </table>
                    </div>

                    <?php 
                    $pdo = new PDO('mysql:host=fastapps04.qut.edu.au;dbname=n9395130', 'n9395130', 'password1');
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    try {
                        //$pdo->beginTransaction();
                        //$insert_string = "INSERT INTO reviews () VALUES ();";
                        //$pdo->exec($insert_string);
                        //$pdo->commit();
                    }
                    catch (PDOException $e) {
                        echo $e->getMessage();
                        //$pdo->rollback();
                    }
                    ?>

            </fieldset>
        </div>
        <!--create reviews section-->
        
        
    </div>
    
    <?php include 'footer.inc' ?>

</body>
</html>
